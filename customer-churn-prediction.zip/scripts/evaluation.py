import pandas as pd
import joblib
from sklearn.metrics import classification_report, confusion_matrix

def evaluate_model(data_path, model_path):
    """Evaluate the trained churn prediction model."""
    df = pd.read_csv(data_path)
    X = df.drop("Churn", axis=1)
    y = df["Churn"]

    model = joblib.load(model_path)
    y_pred = model.predict(X)

    print("Confusion Matrix:")
    print(confusion_matrix(y, y_pred))
    print("\nClassification Report:")
    print(classification_report(y, y_pred))

if __name__ == "__main__":
    evaluate_model("data/processed_customer_data.csv", "models/churn_model.pkl")
