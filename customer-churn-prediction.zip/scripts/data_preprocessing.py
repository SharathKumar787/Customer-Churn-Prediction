import pandas as pd

def load_data(file_path):
    """Load dataset from a CSV file."""
    return pd.read_csv(file_path)

def preprocess_data(df):
    """Basic preprocessing: handle missing values & encode categorical features."""
    df = df.dropna()  # Remove missing values
    df = pd.get_dummies(df, drop_first=True)  # One-hot encoding
    return df

if __name__ == "__main__":
    data = load_data("data/customer_data.csv")
    processed_data = preprocess_data(data)
    processed_data.to_csv("data/processed_customer_data.csv", index=False)
    print("Data preprocessing complete.")
