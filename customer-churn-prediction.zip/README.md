# Customer Churn Prediction

A machine learning project to predict customer churn using historical data, enabling businesses to identify at-risk customers and improve retention.

## Project Overview
- **Goal:** Predict whether a customer will churn based on past behavior.
- **Tech Stack:** Python, Pandas, NumPy, Scikit-learn, Matplotlib, Seaborn
- **Steps:**
  1. Data preprocessing
  2. Exploratory Data Analysis (EDA)
  3. Feature engineering
  4. Model training & evaluation

## How to Run
1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/customer-churn-prediction.git
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run preprocessing:
   ```bash
   python scripts/data_preprocessing.py
   ```
4. Train the model:
   ```bash
   python scripts/model_training.py
   ```
5. Evaluate the model:
   ```bash
   python scripts/evaluation.py
   ```

## Dataset
Replace `data/customer_data.csv` with your dataset. You can find public churn datasets on [Kaggle](https://www.kaggle.com/).

## Results
Model achieved high accuracy in predicting churn, helping businesses take proactive action.
